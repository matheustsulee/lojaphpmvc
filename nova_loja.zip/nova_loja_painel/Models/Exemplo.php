<?php
namespace Models;

use \Core\Model;

class Exemplo extends Model {

	public function getAll() {
		$array = array();

		return $array;
	}

}