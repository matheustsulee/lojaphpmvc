<h1>Obrigado pela compra</h1>
Em breve você receberá a confirmação da compra no seu e-mail.